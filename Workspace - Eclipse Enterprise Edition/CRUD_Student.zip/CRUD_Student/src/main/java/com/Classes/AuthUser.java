package com.Classes;

public class AuthUser {
	public static int authUser = 0;
}
